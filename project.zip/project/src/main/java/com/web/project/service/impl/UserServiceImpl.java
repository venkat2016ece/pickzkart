package com.web.project.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.project.dao.UserDao;
import com.web.project.model.User;
import com.web.project.service.UserService;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserDao userDao;

    public void addUser(User user){
        userDao.addUser(user);
    }

    public User getUserById(int userId){
        return userDao.getUserById(userId);
    }

    public List<User> getAllUsers(){
        return userDao.getAllUsers();
    }

    public User getUserByUsername (String username){
        return userDao.getUserByUsername(username);
    }

	public User updateUser(User user) {
		return userDao.updateUser(user);
	}

	public void deleteUser(Integer userId) {
		  userDao.deleteUser(userId);
		
	}


} // The End of Class;
