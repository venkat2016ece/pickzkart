package com.web.project.dao;

import java.util.List;

import com.web.project.model.User;

public interface UserDao {
	void addUser(User user);

    public User getUserById(int userId);

    public List<User> getAllUsers();

    public User getUserByUsername(String username);
    
    public User updateUser(User user);
    
    public void deleteUser(Integer  userId );
}
