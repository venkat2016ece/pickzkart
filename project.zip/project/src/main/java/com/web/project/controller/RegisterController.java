package com.web.project.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.web.project.model.User;
import com.web.project.service.UserService;



@Controller
public class RegisterController {
	
	 @Autowired
	    private UserService userService;

	    @RequestMapping("/register")
	    public String registerUser(Model model){
	        User user = new User();
	        

	        model.addAttribute("user", user);

	        return "Register";
	    }


	    @RequestMapping(value = "/register", method = RequestMethod.POST)
	    public String registerUserPost(@Valid @ModelAttribute("user") User user, BindingResult result, Model model){

	        if(result.hasErrors()){
	            return "Register";
	        }

	        List<User> userList = userService.getAllUsers();

	        for (int i=0; i< userList.size(); i++){
	            if(user.getUserEmail().equals(userList.get(i).getUserEmail())){
	                model.addAttribute("emailMsg", "Email already exists");

	                return "Register";
	            }

	            if(user.getUsername().equals(userList.get(i).getUsername())){
	                model.addAttribute("usernameMsg", "Username already exists");

	                return "Register";
	            }
	        }

	        user.setEnabled(true);
	        userService.addUser(user);
	        return "RegisterSuccess";
	    }

	} // The End of Class;


