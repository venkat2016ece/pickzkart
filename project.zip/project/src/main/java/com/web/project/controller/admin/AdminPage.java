package com.web.project.controller.admin;



import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.project.model.User;
import com.web.project.service.UserService;

@Controller
@RequestMapping("/adminhome")
public class AdminPage {

    

    @Autowired
    private UserService userService;

    @RequestMapping
    public String adminPage(){
        return "adminhome";
    }

   

    @RequestMapping("/user")
    public String userManagerment(Model model){

        List<User> userList = userService.getAllUsers();
        model.addAttribute("userList", userList);

        return "usermanagement";
    }
    @RequestMapping(value = "/editUser", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int userId = Integer.parseInt(request.getParameter("userId"));
		User user = userService.getUserById(userId);
		ModelAndView model = new ModelAndView("UserForm");
		model.addObject("user", user);

		return model;
	}
    
    @RequestMapping(value="/saveUser",method=RequestMethod.POST)
    	public ModelAndView saveUser(@ModelAttribute User user){
    		if(user.getUserId()==0){
    			userService.addUser(user);
    		}else{
    			userService.updateUser(user);
    			}
    		return new ModelAndView("adminhome");
    		}
    	
    
    @RequestMapping(value = "/deleteUser", method = RequestMethod.GET)
	public ModelAndView deleteUser(HttpServletRequest request) {
		int userId = Integer.parseInt(request.getParameter("userId"));
		userService.deleteUser(userId);
		return new ModelAndView("adminhome");
    }

} // The End of Class;
