

package com.web.project.service;


import java.util.List;

import com.web.project.model.User;



public interface UserService {

    void addUser(User user);

    User getUserById(int userId);

    List<User> getAllUsers();

    User getUserByUsername(String username);
    
    public User updateUser(User user);
    
    public void deleteUser(Integer  userId );

}
