package com.web.project.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.web.project.dao.UserDao;
import com.web.project.model.Authorities;
import com.web.project.model.User;

 

 

@Repository
@Transactional
public class UserDaoImpl implements UserDao{

    @Autowired
    private SessionFactory sessionFactory;

    public void addUser(User user){
        Session session = sessionFactory.getCurrentSession();
        User  c=new User();
        c.setUserId(user.getUserId());
        c.setUserEmail(user.getUserEmail());
        c.setCustomerName(user.getCustomerName());
        c.setUserPhone(user.getUserPhone());
        c.setEnabled(false);
        c.setAuthority("");
        c.setPassword(user.getPassword());
        c.setUsername(user.getUsername());

        
        Authorities newAuthorities = new Authorities();
        newAuthorities.setUsername(user.getUsername());
        newAuthorities.setAuthority("ROLE_USER");
        session.saveOrUpdate(c);
        session.saveOrUpdate(newAuthorities);

        

        session.flush();
    }

    public User getUserById(int userId){
        Session session = sessionFactory.getCurrentSession();
        return (User) session.get(User.class, userId);
    }

    public List<User> getAllUsers(){
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from User");
        @SuppressWarnings("unchecked")
		List<User> userList = query.list();

        return userList;

    }

    public User getUserByUsername(String username){
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from User where username = ?");
        query.setString(0, username);


        return (User) query.uniqueResult();
    }

	public  User updateUser(User user) {
		sessionFactory.getCurrentSession().update(user);
		return user;
	}

	public void deleteUser(Integer userId) {
		User user=(User)sessionFactory.getCurrentSession().load(User.class,userId);
		if(null!=user){
			this.sessionFactory.getCurrentSession().delete(user);
			 

		}
		
	}
    


} // The End of Class;

